Fios stores sheet session here (shared layout with iPFaker license code).
